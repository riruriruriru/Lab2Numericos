Para ejecutar el programa se debe hacer lo siguiente:
Abrir la terminal e ir a la direccion de la carpeta Armadillo
Luego, ejecutar el comando: sh command2 si se quiere correr el programa con openmp. Este comando compila y ejecuta inmediatamente el archivo resultante main.

Si no se quiere ejecutar con openmp, se debe usar el comando sh command

Para ambos casos se requiere tener instalado python 3.6 para la visualización de gráficos y además numpy y matplotlib.
Además, se incluye el programa MainLab2.m en la carpeta Matlab que incluye el método de mínimos cuadrados, con el cálculo de sus resultados y error respectivo, además de un gráfico de los tiempos
del método.
